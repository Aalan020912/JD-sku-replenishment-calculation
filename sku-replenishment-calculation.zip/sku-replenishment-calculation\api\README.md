# API接口说明

本skill调用以下API接口完成补货计算和采购建单功能。

## 接口清单

| 接口名 | 配置文件 | 类型 | 功能说明 |
|--------|---------|------|---------|
| 供应商产能查询 | 供应商产能查询.json | 查询 | 查询SKU在供应商处的可供货产能上限(产能回告) |
| 采购建单上传 | 采购建单上传.json | 操作 | 上传采购建单Excel模板,创建采购单 |

## 接口详情

### 1. 供应商产能查询接口

**接口ID**: a7f3c9e21b8d4f6a90c2e5d1f4b7a8c3  
**接口路径**: `/scm/supplier/capacity/batchQuery`  
**请求方式**: POST  
**内容类型**: application/json  
**处理方式**: 同步返回

#### 功能说明
批量查询指定SKU在指定供应商处的可供货产能上限(产能回告),用于在补货计算后对补货量进行封顶,避免下单量超过供应商实际供货能力。

#### 调用场景
- 配置项"启用产能约束"为true时触发
- 在解析Excel后、计算补货量前调用

#### 参数映射关系

| 参数名 | 来源 | 说明 |
|--------|------|------|
| skuSupplierList | 解析Excel后的SKU列表 | SKU与供应商映射列表,每项含skuId和supplierId |

#### 调用示例
```python
# 查询供应商产能回告
response = call_api(
    api_id="a7f3c9e21b8d4f6a90c2e5d1f4b7a8c3",
    params={
        "skuSupplierList": [
            {"skuId": "SKU001", "supplierId": "S10001"}
        ]
    }
)
```

#### 响应处理
```python
if response['code'] == 200:
    capacity_list = response['data']['capacityList']
    # 每项含: skuId, supplierId, maxSupplyQty, leadTimeDays, capacityStatus
    # capacityStatus: normal=正常, limited=受限, unavailable=无法供货
    sku_list = calculator.merge_capacity_data(sku_list, capacity_list)
else:
    handle_error(response['message'])
```

#### 产能状态处理

| capacityStatus | 含义 | 处理方式 |
|----------------|------|---------|
| normal | 产能正常 | 补货量未超上限则不调整 |
| limited | 产能受限 | 补货量按maxSupplyQty封顶,标记需人工审核 |
| unavailable | 无法供货 | 补货量置0,需人工确认替代供应商 |
| 无回告记录 | 暂无数据 | 该SKU按无约束处理 |

---

### 2. 采购建单上传接口

**接口ID**: 4cfa0d398483e77200deba2fe1aa2f29  
**接口路径**: `/poes/upload/uploadExcel`  
**请求方式**: POST  
**内容类型**: multipart/form-data

#### 功能说明
上传采购建单Excel模板,系统解析Excel数据并创建采购单建单任务。

#### 调用场景
- 用户上传补货计算结果Excel文件
- 系统自动填充采购建单模板
- 创建采购单建单任务

#### 参数映射关系

| 参数名 | 来源 | 说明 |
|--------|------|------|
| excelFile | 用户上传 | 补货计算结果Excel文件 |
| templateType | 固定值 | normal |
| stockingType | config/备货类型.json | 默认5(日常备货) |
| excreteNum | config/明细拆单数量.json | 默认40 |
| checkExcelOnly | 固定值 | false(直接建单) |
| threadPoolQuery | 固定值 | true |
| taskName | 自动生成 | 补货建单_时间戳 |

#### 调用示例
```python
# 调用采购建单上传接口
response = call_api(
    api_id="4cfa0d398483e77200deba2fe1aa2f29",
    params={
        "excelFile": excel_file_path,
        "templateType": "normal",
        "stockingType": "5",
        "excreteNum": "40",
        "checkExcelOnly": False,
        "threadPoolQuery": True,
        "taskName": f"补货建单_{datetime.now().strftime('%Y%m%d%H%M%S')}"
    }
)
```

#### 响应处理
```python
if response['code'] == 200:
    task_id = response['data']['taskId']
    # 轮询查询建单结果
    # TODO: 实现结果查询逻辑
else:
    # 错误处理
    handle_error(response['message'])
```

## 调用顺序

1. **步骤1**: 用户上传Excel → 系统解析数据
2. **步骤2**: 调用供应商产能查询接口 → 获取产能回告并合并(启用产能约束时)
3. **步骤3**: 计算补货量(按产能封顶) → 生成建单Excel
4. **步骤4**: 调用采购建单上传接口 → 创建采购单

## 错误处理

### 常见错误码

| 错误码 | 错误说明 | 处理方式 |
|--------|---------|---------|
| 400 | 参数错误 | 检查参数格式和必填项 |
| 401 | 未授权 | 重新登录获取Cookie |
| 500 | 服务器错误 | 稍后重试或联系技术支持 |

### 重试策略
- 最大重试次数: 3次
- 重试间隔: 2秒
- 重试条件: 网络错误、超时

### 异常场景处理
1. **Excel上传失败**: 提示用户检查文件格式和大小
2. **Excel解析失败**: 提示用户检查模板格式
3. **建单失败**: 记录失败原因,提示用户人工介入

## Cookie体系

本接口使用 **erp** Cookie体系(采销体系)

### Cookie获取
```bash
# 登录ERP获取Cookie
python3 ~/.openclaw/workspace/skills/api-assistant-alpha/scripts/login_jd.py erp
```

### 401处理流程
1. 重新登录获取新Cookie
2. 重试接口调用
3. 重试仍401 → 权限问题,联系管理员

## 注意事项

1. **文件大小**: Excel文件建议≤5MB
2. **文件格式**: 支持.xlsx/.xls格式
3. **异步处理**: 上传成功后返回任务ID,需轮询查询结果
4. **任务名称**: 最长50字符

---

**重要**: 所有API调用必须通过统一代理,禁止直接调用目标接口。
