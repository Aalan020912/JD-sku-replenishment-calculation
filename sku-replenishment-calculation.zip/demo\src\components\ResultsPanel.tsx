import { useState } from 'react'
import { AlertTriangle, CheckCircle2, Package, FileCheck, Truck, Info } from 'lucide-react'
import type { RunOutput } from '../lib/runner'
import type { ReplenishmentResult } from '../lib/types'

interface Props {
  output: RunOutput | null
  running: boolean
}

function StatCard({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone: string }) {
  return (
    <div className={`rounded-xl border px-3 py-2.5 ${tone}`}>
      <div className="text-[11px] text-slate-500">{label}</div>
      <div className="text-xl font-bold text-slate-800 leading-tight">{value}</div>
      {sub && <div className="text-[10px] text-slate-400">{sub}</div>}
    </div>
  )
}

function Row({ r }: { r: ReplenishmentResult }) {
  const [open, setOpen] = useState(false)
  const capped = r.warnings.some((w) => w.includes('产能受限'))
  return (
    <>
      <tr
        onClick={() => setOpen(!open)}
        className={`cursor-pointer border-b border-slate-100 hover:bg-slate-50 ${
          r.need_manual_review ? 'bg-amber-50/40' : ''
        }`}
      >
        <td className="py-1.5 px-2 font-mono text-[12px] text-slate-700">{r.sku_id}</td>
        <td className="py-1.5 px-2 text-right font-semibold text-slate-800">
          {r.replenishment_qty}
          {capped && <span className="ml-1 text-[9px] text-amber-600">封顶</span>}
        </td>
        <td className="py-1.5 px-2 text-right text-slate-500">{r.suggested_qty}</td>
        <td className="py-1.5 px-2 text-right text-slate-500">{r.daily_sales.toFixed(1)}</td>
        <td className="py-1.5 px-2 text-center">
          {r.need_manual_review ? (
            <span className="inline-flex items-center gap-0.5 text-[10px] text-amber-700 bg-amber-100 rounded px-1.5 py-0.5">
              <AlertTriangle className="w-3 h-3" />审核
            </span>
          ) : (
            <span className="inline-flex items-center gap-0.5 text-[10px] text-emerald-700 bg-emerald-100 rounded px-1.5 py-0.5">
              <CheckCircle2 className="w-3 h-3" />正常
            </span>
          )}
        </td>
      </tr>
      {open && (
        <tr className="bg-slate-50/70">
          <td colSpan={5} className="px-3 py-2">
            <div className="text-[11px] text-slate-600 space-y-0.5">
              <div className="font-medium text-slate-500 flex items-center gap-1">
                <Info className="w-3 h-3" />计算过程
              </div>
              {r.calculation_notes.map((n, i) => (
                <div key={i} className="pl-4 font-mono text-[10.5px]">• {n}</div>
              ))}
              {r.warnings.length > 0 && (
                <div className="pl-4 text-amber-700">
                  {r.warnings.map((w, i) => (
                    <div key={i}>⚠ {w}</div>
                  ))}
                </div>
              )}
            </div>
          </td>
        </tr>
      )}
    </>
  )
}

export default function ResultsPanel({ output, running }: Props) {
  if (!output) {
    return (
      <div className="flex h-full flex-col items-center justify-center text-center text-slate-400">
        <Package className="w-12 h-12 mb-3 opacity-40" />
        <p className="text-sm">运行 Skill 后，这里展示补货结果</p>
        <p className="text-[11px] mt-1">补货量 · 异常清单 · 建单结果</p>
      </div>
    )
  }

  const { stats, results, purchaseRows, uploadTask } = output

  return (
    <div className="flex flex-col gap-3 h-full overflow-hidden">
      <div className="grid grid-cols-2 gap-2">
        <StatCard label="SKU总数" value={String(stats.totalSku)} tone="border-slate-200 bg-white" />
        <StatCard
          label="需人工审核"
          value={String(stats.needReview)}
          tone="border-amber-200 bg-amber-50"
        />
        <StatCard
          label="平均补货量"
          value={String(stats.avgQty)}
          sub="件/SKU"
          tone="border-slate-200 bg-white"
        />
        <StatCard
          label="可下单SKU"
          value={String(purchaseRows.length)}
          sub="进入建单模板"
          tone="border-emerald-200 bg-emerald-50"
        />
      </div>

      {uploadTask ? (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 flex items-center gap-2">
          <Truck className="w-4 h-4 text-emerald-600" />
          <div className="text-[11px]">
            <span className="font-medium text-emerald-800">采购单已创建</span>
            <span className="text-emerald-600 font-mono ml-1">{uploadTask.taskId}</span>
            <span className="text-emerald-600 ml-1">· {uploadTask.count}个SKU</span>
          </div>
        </div>
      ) : (
        <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 flex items-center gap-2">
          <FileCheck className="w-4 h-4 text-slate-500" />
          <div className="text-[11px] text-slate-600">
            仅计算完成，未建单（自动建单开关默认关闭）
          </div>
        </div>
      )}

      <div className="flex-1 overflow-auto rounded-xl border border-slate-200 bg-white">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-slate-50 text-[11px] text-slate-500">
            <tr className="border-b border-slate-200">
              <th className="py-2 px-2 text-left font-medium">SKU</th>
              <th className="py-2 px-2 text-right font-medium">补货量</th>
              <th className="py-2 px-2 text-right font-medium">建议量</th>
              <th className="py-2 px-2 text-right font-medium">日均</th>
              <th className="py-2 px-2 text-center font-medium">状态</th>
            </tr>
          </thead>
          <tbody>
            {results.map((r) => (
              <Row key={r.sku_id} r={r} />
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-[10px] text-slate-400 text-center">点击任意行展开该SKU的计算过程与异常明细</p>
    </div>
  )
}
