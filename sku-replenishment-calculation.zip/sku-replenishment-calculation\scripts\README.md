# 脚本工具说明

本skill使用以下Python脚本完成补货计算和Excel处理功能。

## 脚本清单

| 脚本名 | 功能说明 | 主要函数 |
|--------|---------|---------|
| calculate_replenishment.py | 补货量计算核心逻辑 | ReplenishmentCalculator |
| excel_processor.py | Excel文件解析和生成 | ExcelProcessor |
| validate_config.py | 配置文件格式与取值校验 | ConfigValidator |

## 脚本详情

### 1. calculate_replenishment.py - 补货量计算脚本

**功能**: 基于销量、库存等数据,智能计算SKU补货建议量

#### 核心类: ReplenishmentCalculator

**初始化参数**:
- `config_path`: 配置文件路径(可选)

**主要方法**:

##### calculate_daily_sales()
计算日均销量
```python
daily_sales, note = calculator.calculate_daily_sales(
    sales_28d=280,
    sales_7d=70,
    has_rain=False,
    sales_14d=None
)
```

**参数说明**:
- `sales_28d`: 28日销量
- `sales_7d`: 7日销量
- `has_rain`: 过去7天是否有雨
- `sales_14d`: 14日销量(雨天场景必需)

**返回值**: (日均销量, 计算说明)

##### get_target_turnover_days()
获取目标周转天数
```python
target_days, note = calculator.get_target_turnover_days()
```

**返回值**: (目标周转天数, 调整说明)

##### calculate_replenishment()
计算单个SKU补货量
```python
result = calculator.calculate_replenishment({
    'sku_id': 'SKU001',
    'sales_28d': 280,
    'sales_7d': 70,
    'current_stock': 50,
    'in_transit_stock': 20,
    'unit_price': 100,
    'inventory_age': 30,
    'has_rain': False
})
```

**输入参数**:
- `sku_id`: SKU ID
- `sales_28d`: 28日销量
- `sales_7d`: 7日销量
- `sales_14d`: 14日销量(可选)
- `current_stock`: 当前库存
- `in_transit_stock`: 在途库存
- `unit_price`: 单价(可选)
- `inventory_age`: 库龄(可选)
- `has_rain`: 过去7天是否有雨

**返回结果**:
```python
{
    'sku_id': 'SKU001',
    'replenishment_qty': 100,        # 补货数量
    'daily_sales': 10.0,              # 日均销量
    'target_turnover_days': 35,       # 目标周转天数
    'orderable_stock': 70,            # 可订购库存
    'warnings': [],                   # 异常提示列表
    'need_manual_review': False,      # 是否需人工审核
    'calculation_notes': [...]        # 计算说明列表
}
```

##### batch_calculate()
批量计算多个SKU补货量
```python
results = calculator.batch_calculate(sku_list)

# 传入基准日期可复现大促场景(不受运行时当天日期影响)
from datetime import datetime
results = calculator.batch_calculate(sku_list, datetime(2026, 5, 1))
```

##### merge_capacity_data()
将产能查询接口返回的回告数据按 (skuId, supplierId) 合并回SKU列表
```python
sku_list = calculator.merge_capacity_data(sku_list, capacity_list)
```

**说明**: 未匹配到回告的SKU会被标记 `capacity_status='unavailable'`,按无约束处理

##### apply_capacity_constraint()
对单个SKU结果应用产能封顶(由 `calculate_replenishment` 内部调用)

| 产能回告 | 处理方式 |
|---------|---------|
| 补货量 ≤ 上限 | 不调整 |
| 补货量 > 上限 | 按上限封顶,标记需人工审核 |
| 上限为0 | 补货量置0,标记需人工审核 |
| 无回告数据 | 按无约束处理,记录提示 |

##### check_anomalies()
按异常类型归类汇总,输出审核清单
```python
summary = calculator.check_anomalies(results)
```

**返回结果**:
```python
{
    'total_sku': 7,
    'need_review_count': 4,
    'auto_order_count': 3,
    'review_sku_ids': ['SKU002', 'SKU005', 'SKU006', 'SKU007'],
    'categories': {
        'large_order': ['SKU006'],
        'long_inventory_age': ['SKU002'],
        'zero_sales': ['SKU005'],
        'capacity_limited': [],
        'supplier_unavailable': [],
        'capacity_unknown': ['SKU001', 'SKU003', 'SKU004'],
        'calculation_error': ['SKU007'],
    }
}
```

##### build_result_table()
构建结果表格(与文件IO分离,便于单测与复用)
```python
df = calculator.build_result_table(results)
```

##### export_to_excel()
导出补货结果到Excel
```python
calculator.export_to_excel(results, 'output/replenishment_result.xlsx')
```

**说明**: 列表字段(异常提示、计算说明)会展平为 ` | ` 分隔的文本,布尔字段转为「是/否」

---

### 2. excel_processor.py - Excel处理脚本

**功能**: 解析用户上传的Excel文件,生成采购建单Excel模板

#### 核心类: ExcelProcessor

**主要方法**:

##### parse_upload_excel()
解析用户上传的数据文件,支持 `.xlsx` / `.xls` / `.csv`
```python
sku_list = processor.parse_upload_excel('templates/补货计算数据样例.csv')
```

**支持的列名映射**:
| 标准字段 | 支持的列名 |
|---------|-----------|
| sku_id | SKU ID, SKU编号, sku_id, skuId |
| sales_28d | 28日销量, 28日有效销量, sales_28d |
| sales_7d | 7日销量, 7日有效销量, sales_7d |
| sales_14d | 14日销量, 14日有效销量, sales_14d |
| current_stock | 当前库存, 现货库存, current_stock |
| in_transit_stock | 在途库存, in_transit_stock |
| unit_price | 单价, unit_price |
| inventory_age | 库龄, 库存天数, inventory_age |
| has_rain | 是否有雨, 雨天标记, has_rain |
| supplier_id | 供应商编号, 供应商ID, supplier_id, supplierId |

**返回值**: SKU数据字典列表

**缺失值语义**: 数值字段缺失按0处理,但 `sales_14d` 保持 `None`。
因为雨天场景必须用14日销量计算,若把缺失当成0会静默算出日均销量0,
掩盖数据缺失问题;保持 `None` 可让计算阶段显式报错并转人工审核。

##### generate_purchase_template()
生成采购建单Excel模板
```python
output_file = processor.generate_purchase_template(
    replenishment_results=results,
    output_path='/tmp/purchase_template.xlsx',
    template_type='normal'
)
```

**参数说明**:
- `replenishment_results`: 补货计算结果列表
- `output_path`: 输出文件路径
- `template_type`: 模板类型,当前仅实现 `normal`;传入 `内采`/`ECLP` 会抛 `NotImplementedError`

**处理逻辑**:
- 自动跳过需要人工审核的SKU
- 自动跳过补货量为0的SKU
- 无可建单SKU时仍输出合法表头,避免建单接口解析失败

##### build_purchase_table()
构建建单表格(与文件IO分离,便于单测筛选规则)
```python
df = processor.build_purchase_table(results)
```

##### validate_excel_format()
验证输入文件格式
```python
validation = processor.validate_excel_format('templates/补货计算数据样例.csv')
```

**返回结果**:
```python
{
    'valid': True,
    'errors': [],           # 阻断性错误,非空则不继续计算
    'warnings': [],         # 非阻断提示
    'sku_count': 7          # 数据行数
}
```

**校验项**:

| 类型 | 检查内容 |
|------|---------|
| 错误 | 缺少必需列(SKU ID/28日销量/7日销量/当前库存) |
| 错误 | 无数据行、文件不存在、格式不支持、解析失败 |
| 警告 | 缺少供应商编号列(产能约束将不生效) |
| 警告 | 雨天SKU缺少14日销量(这些SKU将转人工审核) |
| 警告 | 文件超过5MB |

---

### 3. validate_config.py - 配置验证脚本

**功能**: 校验 `config/` 目录下所有配置文件的格式与取值,建议修改配置后执行

#### 核心类: ConfigValidator

**初始化参数**:
- `config_dir`: 配置目录路径(可选,默认为skill根目录下的 `config/`)

**主要方法**:

##### validate_all()
验证全部配置文件
```python
from validate_config import ConfigValidator

validator = ConfigValidator()
passed, errors, warnings = validator.validate_all()
```

**返回值**: (是否全部通过, 错误列表, 警告列表)

**校验项**:
- 必需字段完整性: `parameterName`/`displayName`/`description`/`type`/`value`/`businessMeaning`
- 类型合法性: 必须为 string/number/boolean/array/object 之一
- 数值类型一致性: `type` 为 number 时 `value` 必须是数值
- 权重取值范围: 文件名含"权重"的参数,取值须在 [0, 1] 区间
- 权重总和: 28日销量权重 + 7日销量权重 = 1

**命令行执行**:
```bash
python3 scripts/validate_config.py
```

**退出码**: 0=验证通过, 1=存在错误

---

## 使用示例

### 完整流程示例

```python
from calculate_replenishment import ReplenishmentCalculator
from excel_processor import ExcelProcessor

input_file = 'templates/补货计算数据样例.csv'

# 1. 创建处理器(从 config/ 目录加载参数,可用关键字参数覆盖)
calculator = ReplenishmentCalculator('config')
processor = ExcelProcessor()

# 2. 验证输入文件
validation = processor.validate_excel_format(input_file)
if not validation['valid']:
    print(f"文件验证失败: {validation['errors']}")
    exit(1)
for warning in validation['warnings']:
    print(f"警告: {warning}")

# 3. 解析数据
sku_list = processor.parse_upload_excel(input_file)
print(f"成功解析 {len(sku_list)} 个SKU")

# 4. 查询产能回告并合并(可选,需接口权限)
# capacity_list = call_api('querySupplierCapacity', ...)
# sku_list = calculator.merge_capacity_data(sku_list, capacity_list)

# 5. 批量计算补货量
results = calculator.batch_calculate(sku_list)

# 6. 异常汇总
summary = calculator.check_anomalies(results)
print(f"可自动建单 {summary['auto_order_count']} 个, "
      f"需人工审核 {summary['need_review_count']} 个")

# 7. 导出结果与建单模板
calculator.export_to_excel(results, 'output/replenishment_result.xlsx')
processor.generate_purchase_template(results, 'output/purchase_template.xlsx')
```

---

## 执行环境

**Python版本**: Python 3.7+

**依赖分层**:

| 模块 | 第三方依赖 | 说明 |
|------|-----------|------|
| calculate_replenishment.py | 无 | 计算逻辑仅用标准库(json/os/math/datetime);pandas 在 `build_result_table` 内按需导入 |
| excel_processor.py | pandas | 表格解析;导出Excel还需 openpyxl |
| validate_config.py | 无 | 仅用标准库 |

**安装依赖**:
```bash
pip install -r requirements.txt
```

---

## 脚本执行

**直接执行**(结果输出到当前目录的 `output/`):
```bash
# 补货计算示例: 5个SKU覆盖正常/长库龄/雨天/产能封顶/零销量
python3 scripts/calculate_replenishment.py

# 完整链路: 解析样例CSV -> 计算 -> 汇总 -> 生成建单模板
python3 scripts/excel_processor.py

# 配置校验
python3 scripts/validate_config.py
```

**运行测试**:
```bash
python3 tests/test_calculation.py   # 27个用例,零第三方依赖
python3 tests/test_pipeline.py      # 26个用例,需 pandas
```

**模块调用**:
```python
import sys
sys.path.insert(0, 'scripts')

from calculate_replenishment import ReplenishmentCalculator
from excel_processor import ExcelProcessor
```

---

## 注意事项

1. **数据类型**: 所有数值字段会自动转换为浮点数,空单元格的 NaN 会被归一化
2. **缺失值处理**: 数值字段缺失按0处理,但 `sales_14d` 保持 `None`(见上文缺失值语义)
3. **布尔值解析**: 支持 'true'/'false', 'yes'/'no', '是'/'否', 1/0 等多种格式
4. **文件大小**: 建议输入文件≤5MB
5. **编码格式**: 统一使用UTF-8,CSV兼容带BOM的Excel导出
6. **异常处理**: 单SKU计算异常会被捕获、写入warnings并转人工审核,不中断批量计算

---

## 错误处理

### 常见错误

| 错误类型 | 错误说明 | 处理方式 |
|---------|---------|---------|
| FileNotFoundError | 文件不存在 | 检查文件路径 |
| ValueError | 权重验证失败 | 检查权重配置 |
| KeyError | 缺少必需列 | 检查Excel格式 |
| TypeError | 数据类型错误 | 检查数据格式 |

### 日志记录

脚本执行过程中的关键信息会打印到控制台,建议通过重定向保存日志:

```bash
python3 scripts/calculate_replenishment.py > logs/replenishment.log 2>&1
```

---

**重要**: 脚本执行前请确保配置文件正确,依赖库已安装。
