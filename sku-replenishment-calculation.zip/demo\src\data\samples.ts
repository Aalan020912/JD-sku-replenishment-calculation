import type { RunScenario } from '../lib/types'

// 演示场景：模拟"自然语言输入 → 数据集 + 参数"的映射
export const SCENARIOS: RunScenario[] = [
  {
    id: 'daily',
    label: '日常补货',
    nlText: '帮我算一下这批SKU的补货量，文件是 sku_data.xlsx',
    description: '常规补货场景，覆盖正常/大额/长库龄/零销量/产能受限五类SKU',
    simulatedDate: '2026-03-15',
    configOverride: {},
    skus: [
      { sku_id: 'SKU001', sales_28d: 280, sales_7d: 70, current_stock: 50, in_transit_stock: 20, unit_price: 100, inventory_age: 30, supplier_id: 'SUP-A', max_supply_qty: 500, capacity_status: 'normal' },
      { sku_id: 'SKU002', sales_28d: 560, sales_7d: 140, current_stock: 100, in_transit_stock: 50, unit_price: 2000, inventory_age: 40, supplier_id: 'SUP-B', max_supply_qty: 800, capacity_status: 'normal' },
      { sku_id: 'SKU003', sales_28d: 420, sales_7d: 105, current_stock: 80, in_transit_stock: 40, unit_price: 150, inventory_age: 120, supplier_id: 'SUP-A', max_supply_qty: 600, capacity_status: 'normal' },
      { sku_id: 'SKU004', sales_28d: 0, sales_7d: 0, current_stock: 30, in_transit_stock: 0, unit_price: 80, inventory_age: 20, supplier_id: 'SUP-C', max_supply_qty: 300, capacity_status: 'normal' },
      { sku_id: 'SKU005', sales_28d: 560, sales_7d: 140, current_stock: 0, in_transit_stock: 0, unit_price: 100, inventory_age: 15, supplier_id: 'SUP-B', max_supply_qty: 200, capacity_status: 'limited' },
    ],
  },
  {
    id: 'promotion',
    label: '618大促备货',
    nlText: '618快到了，按大促标准算备货量，文件 promotion_sku.xlsx',
    description: '模拟日期为 5/10（大促前20天），目标周转自动从35天调整为45天',
    simulatedDate: '2026-05-10',
    configOverride: {},
    skus: [
      { sku_id: 'PROMO01', sales_28d: 280, sales_7d: 70, current_stock: 50, in_transit_stock: 20, unit_price: 120, inventory_age: 25, supplier_id: 'SUP-A', max_supply_qty: 500, capacity_status: 'normal' },
      { sku_id: 'PROMO02', sales_28d: 560, sales_7d: 140, current_stock: 100, in_transit_stock: 50, unit_price: 90, inventory_age: 18, supplier_id: 'SUP-B', max_supply_qty: 600, capacity_status: 'limited' },
      { sku_id: 'PROMO03', sales_28d: 840, sales_7d: 210, current_stock: 120, in_transit_stock: 30, unit_price: 60, inventory_age: 22, supplier_id: 'SUP-C', max_supply_qty: 1500, capacity_status: 'normal' },
      { sku_id: 'PROMO04', sales_28d: 420, sales_7d: 105, current_stock: 60, in_transit_stock: 0, unit_price: 3500, inventory_age: 12, supplier_id: 'SUP-A', max_supply_qty: 900, capacity_status: 'normal' },
    ],
  },
  {
    id: 'rain',
    label: '雨天重新计算',
    nlText: '最近连续下雨，用14日销量重新算一下补货，文件 rain_sku.xlsx',
    description: '雨天场景：7日权重降为0，改用14日销量推算日均，避免低估需求',
    simulatedDate: '2026-03-20',
    configOverride: {},
    skus: [
      { sku_id: 'RAIN01', sales_28d: 280, sales_7d: 35, sales_14d: 140, current_stock: 50, in_transit_stock: 20, unit_price: 100, inventory_age: 30, has_rain: true, supplier_id: 'SUP-A', max_supply_qty: 500, capacity_status: 'normal' },
      { sku_id: 'RAIN02', sales_28d: 560, sales_7d: 70, sales_14d: 280, current_stock: 80, in_transit_stock: 40, unit_price: 150, inventory_age: 25, has_rain: true, supplier_id: 'SUP-B', max_supply_qty: 600, capacity_status: 'normal' },
      { sku_id: 'RAIN03', sales_28d: 420, sales_7d: 105, current_stock: 60, in_transit_stock: 10, unit_price: 90, inventory_age: 20, has_rain: false, supplier_id: 'SUP-C', max_supply_qty: 400, capacity_status: 'normal' },
    ],
  },
  {
    id: 'no_capacity',
    label: '关闭产能约束对比',
    nlText: '先不看供应商产能，直接按需求算补货量',
    description: '关闭产能约束开关：产能查询节点被跳过，补货量不受供应商上限封顶（用于对比）',
    simulatedDate: '2026-03-15',
    configOverride: { enableCapacityConstraint: false },
    skus: [
      { sku_id: 'SKU001', sales_28d: 280, sales_7d: 70, current_stock: 50, in_transit_stock: 20, unit_price: 100, inventory_age: 30, supplier_id: 'SUP-A', max_supply_qty: 500, capacity_status: 'normal' },
      { sku_id: 'SKU005', sales_28d: 560, sales_7d: 140, current_stock: 0, in_transit_stock: 0, unit_price: 100, inventory_age: 15, supplier_id: 'SUP-B', max_supply_qty: 200, capacity_status: 'limited' },
    ],
  },
]

// 轻量"自然语言"识别：把任意输入映射到最匹配的场景
export function matchScenario(text: string): RunScenario {
  const t = text.toLowerCase()
  if (/大促|618|双11|双十一|促销|备货/.test(text)) return SCENARIOS[1]
  if (/雨|下雨|天气|14日/.test(text)) return SCENARIOS[2]
  if (/关闭产能|不看产能|不考虑产能|无约束/.test(text)) return SCENARIOS[3]
  return SCENARIOS[0]
}
