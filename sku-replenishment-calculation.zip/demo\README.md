# SKU补货 Skill · Web 可视化演示

将 `sku-replenishment-calculation` 这个 Agent Skill 做成可交互演示：**自然语言输入 → DAG 工作流逐节点执行动画 → 补货结果与异常清单**，直观展示 skill 的端到端工作流程。

> 计算逻辑（日均销量 / 大促周转 / 雨天降权 / 供应商产能约束 / 异常拦截）**忠实移植自** `../sku-replenishment-calculation/scripts/calculate_replenishment.py`，保证演示结果与真实 skill 一致。

## 技术栈

- Vite + React 18 + TypeScript
- TailwindCSS（样式）
- lucide-react（图标）
- 纯前端，无后端依赖：Mock API + 内置样例数据

## 环境要求

- **Node.js 18+**（本机通过 conda 安装了 Node 20）

## 快速开始

```powershell
# 进入 demo 目录
cd demo

# 安装依赖（首次）
npm install

# 启动开发服务器（支持热更新）
npm run dev
# 打开 http://localhost:5173
```

生产构建：

```powershell
npm run build      # 产物在 dist/
npm run preview    # 本地预览构建产物
```

## 界面说明（三栏）

- **左栏 · 输入面板**：自然语言指令（关键词识别）、4个演示场景、"自动创建采购单"开关、运行按钮
- **中栏 · DAG 工作流**：11 节点有向无环图，逐节点高亮执行（蓝=执行中/绿=完成/黄=命中异常/虚线=条件跳过），下方为实时执行日志
- **右栏 · 结果面板**：统计卡片、补货结果表（点击行展开计算过程与异常明细）、建单结果

## 演示场景

| 场景 | 演示要点 |
|------|---------|
| 日常补货 | 正常计算 + 大额/长库龄/零销量/产能受限四类异常拦截 |
| 618大促备货 | 模拟大促前20天，目标周转自动 35→45 天 |
| 雨天重新计算 | 7日权重降为0，改用14日销量推算 |
| 关闭产能约束对比 | 产能查询节点被条件跳过，补货量不受产能封顶 |

## 与真实 Skill 的对应关系

| Demo 模块 | 真实 skill 资产 |
|-----------|----------------|
| `src/lib/skill.ts` | `scripts/calculate_replenishment.py` + `excel_processor.py` |
| `src/lib/dag.ts` | `manifest.json`（DAG 节点/边/条件） |
| Mock：供应商产能查询 | `api/供应商产能查询.json` |
| Mock：采购建单上传 | `api/采购建单上传.json` |
| 配置默认值 | `config/*.json` |

## 目录结构

```
demo/
├── index.html
├── package.json
├── vite.config.ts
├── tailwind.config.js
└── src/
    ├── App.tsx                 # 三栏布局 + 状态编排
    ├── lib/
    │   ├── types.ts            # 类型定义
    │   ├── skill.ts            # 计算内核（移植自 Python）
    │   ├── dag.ts              # DAG 结构镜像（对应 manifest.json）
    │   └── runner.ts           # DAG 执行引擎（逐节点动画）
    ├── data/samples.ts         # 演示样例数据 + 自然语言映射
    └── components/
        ├── InputPanel.tsx      # 左栏
        ├── DagCanvas.tsx       # 中栏 DAG 画布
        └── ResultsPanel.tsx    # 右栏结果
```

## 说明

- 演示环境中，供应商产能回告、采购建单上传均为 **Mock**（真实 skill 对接京东内网接口）。
- 自然语言识别为**关键词匹配**（大促 / 雨天 / 产能），用于模拟平台的自然语言路由，非 LLM 调用，无需 API Key。
