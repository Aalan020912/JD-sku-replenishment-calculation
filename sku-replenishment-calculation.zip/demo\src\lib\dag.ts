// DAG 结构镜像：与 manifest.json 的节点/边保持一致
import type { DagNode, DagEdge } from './types'

export const DAG_NODES: DagNode[] = [
  {
    id: 'validate_excel',
    type: 'code_interpreter',
    display_name: '验证Excel格式',
    depends_on: [],
    detail: 'scripts/excel_processor.py :: validate_excel_format',
  },
  {
    id: 'load_config',
    type: 'code_interpreter',
    display_name: '加载配置参数',
    depends_on: [],
    detail: 'scripts/calculate_replenishment.py :: _load_config',
  },
  {
    id: 'parse_excel',
    type: 'code_interpreter',
    display_name: '解析Excel数据',
    depends_on: ['validate_excel'],
    detail: 'scripts/excel_processor.py :: parse_upload_excel',
  },
  {
    id: 'query_supplier_capacity',
    type: 'api_call',
    display_name: '查询供应商产能回告',
    depends_on: ['parse_excel'],
    condition: 'enableCapacityConstraint',
    detail: 'api/供应商产能查询.json :: querySupplierCapacity',
  },
  {
    id: 'merge_capacity',
    type: 'code_interpreter',
    display_name: '合并产能回告数据',
    depends_on: ['parse_excel', 'query_supplier_capacity'],
    detail: 'scripts/calculate_replenishment.py :: merge_capacity_data',
  },
  {
    id: 'calculate_replenishment',
    type: 'code_interpreter',
    display_name: '计算补货建议量',
    depends_on: ['merge_capacity', 'load_config'],
    detail: 'scripts/calculate_replenishment.py :: batch_calculate',
  },
  {
    id: 'check_anomalies',
    type: 'code_interpreter',
    display_name: '检查异常场景',
    depends_on: ['calculate_replenishment'],
    detail: '大额 / 长库龄 / 零销量 / 产能受限拦截',
  },
  {
    id: 'export_results',
    type: 'code_interpreter',
    display_name: '导出计算结果',
    depends_on: ['check_anomalies'],
    detail: 'scripts/calculate_replenishment.py :: export_to_excel',
  },
  {
    id: 'generate_template',
    type: 'code_interpreter',
    display_name: '生成建单模板',
    depends_on: ['export_results'],
    detail: 'scripts/excel_processor.py :: generate_purchase_template',
  },
  {
    id: 'upload_purchase_order',
    type: 'api_call',
    display_name: '上传采购建单',
    depends_on: ['generate_template'],
    condition: 'autoCreatePurchaseOrder',
    detail: 'api/采购建单上传.json :: uploadExcel',
  },
  {
    id: 'notify_user',
    type: 'tool_call',
    display_name: '通知用户',
    depends_on: ['export_results', 'upload_purchase_order'],
    detail: 'tool: message',
  },
]

export const DAG_EDGES: DagEdge[] = [
  { from: 'validate_excel', to: 'parse_excel' },
  { from: 'parse_excel', to: 'query_supplier_capacity' },
  { from: 'parse_excel', to: 'merge_capacity' },
  { from: 'query_supplier_capacity', to: 'merge_capacity' },
  { from: 'merge_capacity', to: 'calculate_replenishment' },
  { from: 'load_config', to: 'calculate_replenishment' },
  { from: 'calculate_replenishment', to: 'check_anomalies' },
  { from: 'check_anomalies', to: 'export_results' },
  { from: 'export_results', to: 'generate_template' },
  { from: 'generate_template', to: 'upload_purchase_order' },
  { from: 'upload_purchase_order', to: 'notify_user' },
  { from: 'export_results', to: 'notify_user' },
]

export const ENTRY_POINTS = ['validate_excel', 'load_config']

// 拓扑分层：用于画布按层级横向排列，体现并行关系
export function computeLayers(): string[][] {
  const nodeMap = new Map(DAG_NODES.map((n) => [n.id, n]))
  const depth = new Map<string, number>()

  function getDepth(id: string): number {
    if (depth.has(id)) return depth.get(id)!
    const node = nodeMap.get(id)!
    if (node.depends_on.length === 0) {
      depth.set(id, 0)
      return 0
    }
    const d = Math.max(...node.depends_on.map((p) => getDepth(p))) + 1
    depth.set(id, d)
    return d
  }

  DAG_NODES.forEach((n) => getDepth(n.id))
  const maxDepth = Math.max(...[...depth.values()])
  const layers: string[][] = Array.from({ length: maxDepth + 1 }, () => [])
  DAG_NODES.forEach((n) => layers[depth.get(n.id)!].push(n.id))
  return layers
}
